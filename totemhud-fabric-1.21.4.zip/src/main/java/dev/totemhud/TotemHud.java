package dev.totemhud;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TotemHud implements ModInitializer {
    public static final String MOD_ID = "totemhud";

    /** How often to sync, in ticks (10 = every 0.5 s). */
    private static final int SYNC_INTERVAL = 10;

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(TotemCountsPayload.ID, TotemCountsPayload.CODEC);

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % SYNC_INTERVAL != 0) return;

            List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
            if (players.isEmpty()) return;

            Map<UUID, Integer> counts = new HashMap<>();
            for (ServerPlayerEntity player : players) {
                counts.put(player.getUuid(), countTotems(player.getInventory()));
            }

            TotemCountsPayload payload = new TotemCountsPayload(counts);
            for (ServerPlayerEntity player : players) {
                if (ServerPlayNetworking.canSend(player, TotemCountsPayload.ID)) {
                    ServerPlayNetworking.send(player, payload);
                }
            }
        });
    }

    /** Counts totems in the whole inventory: hotbar, main, armor, offhand. */
    public static int countTotems(PlayerInventory inventory) {
        int total = 0;
        for (int i = 0; i < inventory.size(); i++) {
            ItemStack stack = inventory.getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                total += stack.getCount();
            }
        }
        return total;
    }
}
