package dev.totemhud;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Server -> client: player UUID -> number of totems in their inventory. */
public record TotemCountsPayload(Map<UUID, Integer> counts) implements CustomPayload {

    public static final CustomPayload.Id<TotemCountsPayload> ID =
            new CustomPayload.Id<>(Identifier.of(TotemHud.MOD_ID, "counts"));

    public static final PacketCodec<RegistryByteBuf, TotemCountsPayload> CODEC = PacketCodec.of(
            (payload, buf) -> {
                buf.writeVarInt(payload.counts().size());
                for (Map.Entry<UUID, Integer> e : payload.counts().entrySet()) {
                    buf.writeUuid(e.getKey());
                    buf.writeVarInt(e.getValue());
                }
            },
            buf -> {
                int size = buf.readVarInt();
                Map<UUID, Integer> map = new HashMap<>();
                for (int i = 0; i < size; i++) {
                    UUID id = buf.readUuid();
                    int count = buf.readVarInt();
                    map.put(id, count);
                }
                return new TotemCountsPayload(map);
            }
    );

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
