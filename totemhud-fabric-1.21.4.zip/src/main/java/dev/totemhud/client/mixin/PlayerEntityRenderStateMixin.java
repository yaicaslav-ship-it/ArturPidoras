package dev.totemhud.client.mixin;

import dev.totemhud.client.TotemCountHolder;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(PlayerEntityRenderState.class)
public class PlayerEntityRenderStateMixin implements TotemCountHolder {
    @Unique
    private int totemhud$count = -1;

    @Override
    public int totemhud$get() {
        return this.totemhud$count;
    }

    @Override
    public void totemhud$set(int value) {
        this.totemhud$count = value;
    }
}
