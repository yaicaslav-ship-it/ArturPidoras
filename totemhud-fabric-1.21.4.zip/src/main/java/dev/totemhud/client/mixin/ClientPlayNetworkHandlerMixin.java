package dev.totemhud.client.mixin;

import dev.totemhud.client.PopTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {

    /** Status 35 = "totem of undying used". RETURN is only reached on the main thread. */
    @Inject(method = "onEntityStatus", at = @At("RETURN"))
    private void totemhud$onStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() != 35) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) return;

        Entity entity = packet.getEntity(client.world);
        if (entity instanceof PlayerEntity player) {
            PopTracker.addPop(player.getUuid());
        }
    }
}
