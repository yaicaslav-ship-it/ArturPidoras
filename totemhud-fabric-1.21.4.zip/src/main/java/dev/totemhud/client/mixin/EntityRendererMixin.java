package dev.totemhud.client.mixin;

import dev.totemhud.client.PopTracker;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {

    /**
     * Appends " -N" (red) to the end of a player's name tag.
     * The name tag itself is drawn by vanilla, so placement/backgrounds stay correct.
     */
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void totemhud$appendPops(Entity entity, EntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (!(entity instanceof PlayerEntity player)) return;

        // A dead player starts over after respawn.
        if (player.getHealth() <= 0.0f) {
            PopTracker.reset(player.getUuid());
            return;
        }

        int pops = PopTracker.get(player.getUuid());
        if (pops <= 0 || state.displayName == null) return;

        state.displayName = state.displayName.copy()
                .append(Text.literal(" -" + pops).formatted(Formatting.RED));
    }
}
