package dev.totemhud.client.mixin;

import dev.totemhud.client.TotemCountHolder;
import dev.totemhud.client.TotemHudClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hooks the base EntityRenderer (both methods are guaranteed to exist there)
 * and only acts on player render states.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {

    @Shadow
    protected abstract void renderLabelIfPresent(EntityRenderState state, Text text,
                                                 MatrixStack matrices,
                                                 VertexConsumerProvider vertexConsumers, int light);

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void totemhud$update(Entity entity, EntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (entity instanceof PlayerEntity player && state instanceof TotemCountHolder holder) {
            holder.totemhud$set(TotemHudClient.getCount(player));
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void totemhud$render(EntityRenderState state, MatrixStack matrices,
                                 VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (!(state instanceof TotemCountHolder holder)) return;

        int count = holder.totemhud$get();
        if (count < 0) return;

        Text label = Text.literal("Тотемов: " + count)
                .formatted(count > 0 ? Formatting.GOLD : Formatting.RED);

        matrices.push();
        matrices.translate(0.0, 0.28, 0.0);
        this.renderLabelIfPresent(state, label, matrices, vertexConsumers, light);
        matrices.pop();
    }
}
