package dev.totemhud.client.mixin;

import dev.totemhud.client.PopTracker;
import dev.totemhud.client.TotemCountHolder;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {

    @Shadow
    protected abstract void renderLabelIfPresent(EntityRenderState state, Text text,
                                                 MatrixStack matrices,
                                                 VertexConsumerProvider vertexConsumers, int light);

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void totemhud$update(Entity entity, EntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (entity instanceof PlayerEntity player && state instanceof TotemCountHolder holder) {
            // A dead player starts over after respawn.
            if (player.getHealth() <= 0.0f) {
                PopTracker.reset(player.getUuid());
            }
            holder.totemhud$set(PopTracker.get(player.getUuid()));
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void totemhud$render(EntityRenderState state, MatrixStack matrices,
                                 VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (!(state instanceof TotemCountHolder holder)) return;

        int pops = holder.totemhud$get();
        if (pops <= 0) return;

        Text label = Text.literal("Попов: " + pops).formatted(Formatting.RED);

        matrices.push();
        matrices.translate(0.0, 0.28, 0.0);
        this.renderLabelIfPresent(state, label, matrices, vertexConsumers, light);
        matrices.pop();
    }
}
