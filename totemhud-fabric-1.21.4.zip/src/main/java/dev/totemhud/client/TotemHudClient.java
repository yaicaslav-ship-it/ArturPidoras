package dev.totemhud.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public class TotemHudClient implements ClientModInitializer {
    public static final String MOD_ID = "totemhud";

    @Override
    public void onInitializeClient() {
        // New server / world -> start counting from zero.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> PopTracker.clear());
    }
}
