package dev.totemhud.client;

import dev.totemhud.TotemCountsPayload;
import dev.totemhud.TotemHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Map;
import java.util.UUID;

public class TotemHudClient implements ClientModInitializer {
    private static volatile Map<UUID, Integer> counts = Map.of();

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(TotemCountsPayload.ID,
                (payload, context) -> counts = payload.counts());

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> counts = Map.of());
    }

    /** @return totem count, or -1 when unknown (nothing is rendered). */
    public static int getCount(PlayerEntity player) {
        Integer fromServer = counts.get(player.getUuid());
        if (fromServer != null) return fromServer;

        // Fallback for servers without the mod.
        int n = 0;
        if (player == MinecraftClient.getInstance().player) {
            n = TotemHud.countTotems(player.getInventory());
        } else {
            ItemStack main = player.getMainHandStack();
            ItemStack off = player.getOffHandStack();
            if (main.isOf(Items.TOTEM_OF_UNDYING)) n += main.getCount();
            if (off.isOf(Items.TOTEM_OF_UNDYING)) n += off.getCount();
        }
        return n > 0 ? n : -1;
    }
}
