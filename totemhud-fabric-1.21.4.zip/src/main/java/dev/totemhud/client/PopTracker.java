package dev.totemhud.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Counts how many times each player popped a totem (seen via server status packets). */
public final class PopTracker {
    /** Forget a player's pops this long after the last one (ms). */
    private static final long EXPIRE_MS = 5 * 60 * 1000L;

    private static final class Entry {
        int pops;
        long last;
    }

    private static final Map<UUID, Entry> ENTRIES = new HashMap<>();

    private PopTracker() {}

    public static synchronized void addPop(UUID player) {
        Entry e = ENTRIES.computeIfAbsent(player, k -> new Entry());
        e.pops++;
        e.last = System.currentTimeMillis();
    }

    /** @return number of pops, 0 if none / expired. */
    public static synchronized int get(UUID player) {
        Entry e = ENTRIES.get(player);
        if (e == null) return 0;
        if (System.currentTimeMillis() - e.last > EXPIRE_MS) {
            ENTRIES.remove(player);
            return 0;
        }
        return e.pops;
    }

    public static synchronized void reset(UUID player) {
        ENTRIES.remove(player);
    }

    public static synchronized void clear() {
        ENTRIES.clear();
    }
}
