package dev.totemhud.client;

/** Duck interface injected into PlayerEntityRenderState. */
public interface TotemCountHolder {
    int totemhud$get();

    void totemhud$set(int value);
}
