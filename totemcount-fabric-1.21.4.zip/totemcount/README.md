# Totem Count (Fabric 1.21.4)

Сборка (нужен JDK 21):
    gradle wrapper --gradle-version 8.12   # один раз, если нет gradlew
    ./gradlew build
Готовый jar: build/libs/totemcount-1.0.0.jar

Положить в mods/ вместе с Fabric API. Мод должен стоять и на сервере, и на клиентах,
чтобы было видно полный инвентарь других игроков.
