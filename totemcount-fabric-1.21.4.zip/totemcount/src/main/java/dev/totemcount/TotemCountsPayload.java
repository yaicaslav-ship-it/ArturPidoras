package dev.totemcount;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Сервер -> клиент: UUID игрока -> число тотемов в его инвентаре. */
public record TotemCountsPayload(Map<UUID, Integer> counts) implements CustomPayload {
    public static final CustomPayload.Id<TotemCountsPayload> ID =
            new CustomPayload.Id<>(Identifier.of(TotemCountMod.MOD_ID, "counts"));

    public static final PacketCodec<RegistryByteBuf, TotemCountsPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.map(size -> new HashMap<UUID, Integer>(), Uuids.PACKET_CODEC, PacketCodecs.VAR_INT),
            TotemCountsPayload::counts,
            TotemCountsPayload::new
    );

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
