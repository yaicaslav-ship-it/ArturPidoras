package dev.totemcount.client.mixin;

import dev.totemcount.client.TotemCountHolder;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(PlayerEntityRenderState.class)
public class PlayerEntityRenderStateMixin implements TotemCountHolder {
    @Unique
    private int totemcount$count = -1;

    @Override
    public int totemcount$get() {
        return totemcount$count;
    }

    @Override
    public void totemcount$set(int value) {
        this.totemcount$count = value;
    }
}
