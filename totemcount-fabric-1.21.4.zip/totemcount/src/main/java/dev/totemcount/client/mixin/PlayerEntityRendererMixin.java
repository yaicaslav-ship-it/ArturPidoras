package dev.totemcount.client.mixin;

import dev.totemcount.client.TotemCountClient;
import dev.totemcount.client.TotemCountHolder;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    @Shadow
    protected abstract void renderLabelIfPresent(PlayerEntityRenderState state, Text text,
                                                 MatrixStack matrices,
                                                 VertexConsumerProvider vertexConsumers, int light);

    /** Запоминаем число тотемов в render state (там нет UUID, поэтому берём здесь). */
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void totemcount$update(AbstractClientPlayerEntity player, PlayerEntityRenderState state,
                                   float tickDelta, CallbackInfo ci) {
        ((TotemCountHolder) state).totemcount$set(TotemCountClient.getCount(player));
    }

    /** Рисуем вторую строку чуть выше ника. */
    @Inject(method = "render", at = @At("TAIL"))
    private void totemcount$render(PlayerEntityRenderState state, MatrixStack matrices,
                                   VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        int count = ((TotemCountHolder) state).totemcount$get();
        if (count < 0) return;

        Text label = Text.literal("Тотемов: " + count)
                .formatted(count > 0 ? Formatting.GOLD : Formatting.RED);

        matrices.push();
        matrices.translate(0.0, 0.28, 0.0); // над ником
        this.renderLabelIfPresent(state, label, matrices, vertexConsumers, light);
        matrices.pop();
    }
}
