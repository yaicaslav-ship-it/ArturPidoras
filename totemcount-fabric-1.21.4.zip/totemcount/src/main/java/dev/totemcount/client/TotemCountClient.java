package dev.totemcount.client;

import dev.totemcount.TotemCountsPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Map;
import java.util.UUID;

public class TotemCountClient implements ClientModInitializer {
    private static volatile Map<UUID, Integer> counts = Map.of();

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(TotemCountsPayload.ID,
                (payload, context) -> counts = payload.counts());

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> counts = Map.of());
    }

    /**
     * @return число тотемов, либо -1 если данных нет (тогда ничего не рисуем).
     */
    public static int getCount(PlayerEntity player) {
        Integer fromServer = counts.get(player.getUuid());
        if (fromServer != null) return fromServer;

        // Фолбэк (сервер без мода): считаем только то, что видно клиенту.
        int n = 0;
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();
        if (main.isOf(Items.TOTEM_OF_UNDYING)) n += main.getCount();
        if (off.isOf(Items.TOTEM_OF_UNDYING)) n += off.getCount();

        if (player == net.minecraft.client.MinecraftClient.getInstance().player) {
            n = 0;
            for (int i = 0; i < player.getInventory().size(); i++) {
                ItemStack s = player.getInventory().getStack(i);
                if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount();
            }
        }
        return n > 0 ? n : -1;
    }
}
