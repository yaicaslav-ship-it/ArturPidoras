package dev.totemcount.client;

/** Интерфейс, который добавляется в PlayerEntityRenderState миксином. */
public interface TotemCountHolder {
    int totemcount$get();
    void totemcount$set(int value);
}
