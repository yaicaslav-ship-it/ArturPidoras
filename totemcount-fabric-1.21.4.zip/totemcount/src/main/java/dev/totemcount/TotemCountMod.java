package dev.totemcount;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TotemCountMod implements ModInitializer {
    public static final String MOD_ID = "totemcount";
    /** Как часто обновлять данные (в тиках). 10 = раз в 0.5 сек. */
    private static final int UPDATE_INTERVAL = 10;

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(TotemCountsPayload.ID, TotemCountsPayload.CODEC);

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % UPDATE_INTERVAL != 0) return;

            List<ServerPlayerEntity> players = server.getPlayerManager().getPlayerList();
            if (players.isEmpty()) return;

            Map<UUID, Integer> counts = new HashMap<>();
            for (ServerPlayerEntity p : players) {
                counts.put(p.getUuid(), countTotems(p));
            }

            TotemCountsPayload payload = new TotemCountsPayload(counts);
            for (ServerPlayerEntity p : players) {
                if (ServerPlayNetworking.canSend(p, TotemCountsPayload.ID)) {
                    ServerPlayNetworking.send(p, payload);
                }
            }
        });
    }

    /** Считает тотемы во всём инвентаре: хотбар, основной, броня, вторая рука. */
    public static int countTotems(ServerPlayerEntity player) {
        PlayerInventory inv = player.getInventory();
        int total = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack stack = inv.getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                total += stack.getCount();
            }
        }
        return total;
    }
}
